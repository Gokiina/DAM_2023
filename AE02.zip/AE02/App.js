import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import Stack1 from './Contenido/Screens/Stack1';
import Drawer1 from './Contenido/Screens/Drawers/Drawer1';
import Drawer2 from './Contenido/Screens/Drawers/Drawer2';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator options="false">
      <Stack.Screen name="Home" component={Stack1} />
      <Stack.Screen name="Screen 1" component={DrawerNavigator} />
    </Stack.Navigator>
  );
};

const DrawerNavigator = () => {
  return (
    <Drawer.Navigator useLegacyImplementation initialRouteName="Home">
      <Drawer.Screen name="Drawer 1" component={Drawer1} />
      <Drawer.Screen name="Drawer 2" component={Drawer2} />
    </Drawer.Navigator>
  );
};

const App = () => (
  <NavigationContainer>
    <StackNavigator />
  </NavigationContainer>
);

export default App;
