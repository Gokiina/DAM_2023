import { StyleSheet, Text, View, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const Stack1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.layout}>
      <Text style={styles.title}>Word Games</Text>
      <Button
        title="GO TO SCREEN 1"
        onPress={() => navigation.navigate('Screen 1')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  layout: {
    flex: 1,
    justifyContent: 'center',
    padding: 8,
  },
  title: { margin: 24, fontSize: 18, fontWeight: 'bold', textAlign: 'center' },
});

export default Stack1;
