// Obtiene las definiciones y las muestra
// Comprueba las letras de la palabra 2 para ver si son correctas y las valida y bloquea
// No he logrado que se escriba solo en la casilla correspondiente ni validar las otras palabras
import { TextInput, Text, ScrollView, View, Button } from 'react-native';
import React, { useEffect, useState } from 'react';
import { Center, Box, Heading, VStack, NativeBaseProvider } from 'native-base';

const App = () => {
  const [definitions, setDefinitions] = useState({});
  const words = ['software', 'developer', 'system', 'app', 'framework'];

  const initialCellStates = Array(words.length).fill(
    Array(10).fill({ value: '', locked: false })
  );

  const [cellStates, setCellStates] = useState(initialCellStates);

  const updateCellState = (wordIndex, letterIndex, text) => {
    setCellStates((prevStates) => {
      const updatedStates = [...prevStates];
      updatedStates[wordIndex][letterIndex] = {
        value: text,
        locked: false,
      };
      return updatedStates;
    });
  };

  const checkLetter = (wordIndex) => {
    const updatedStates = [...cellStates];
    const userInput = updatedStates[wordIndex]
      .map((cell) => cell.value)
      .join('');
    const correctWord = words[wordIndex];

    for (let letterIndex = 0; letterIndex < correctWord.length; letterIndex++) {
      const input = updatedStates[wordIndex][letterIndex].value;
      const correctLetter = correctWord[letterIndex];

      if (input === correctLetter) {
        // La letra es correcta, bloquearla
        updatedStates[wordIndex][letterIndex].locked = true;
      } else {
        // La letra es incorrecta, borrarla
        updatedStates[wordIndex][letterIndex].value = '';
      }
    }

    // Actualizar el estado
    setCellStates(updatedStates);
  };

  // Obtener definiciones - DONE
  const getDefinitions = async () => {
    let newDefinitions = [];
    for (let word of words) {
      try {
        const response = await fetch(
          `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`
        );
        const data = await response.json();
        const definition =
          data[0]?.meanings[0]?.definitions[0]?.definition ||
          'Definition not found';
        newDefinitions.push(definition);
      } catch (error) {
        console.error('Error fetching definition:', error);
        newDefinitions.push('Error fetching definition');
      }
    }
    setDefinitions(newDefinitions);
  };

  return (
    <NativeBaseProvider>
      <Center w="100%">
        <Box safeArea p="2" w="90%" maxW="290" py="5">
          <Heading
            size="lg"
            color="coolGray.800"
            _dark={{ color: 'warmGray.50' }}
            fontSize="50"
            fontWeight="semibold"
            onPress={getDefinitions}>
            Crosswords
          </Heading>

          <VStack space={2} mt="5">
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ flexDirection: 'column' }}>
                  <View style={{ flexDirection: 'column' }}>
                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 134 }}></View>
                      <View style={{ width: 16 }}>
                        <Text style={{ fontSize: 20 }}>1</Text>
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 16 }}>
                        <Text
                          style={{ fontSize: 20 }}
                          onPress={() => checkLetter(1)}>
                          2
                        </Text>
                      </View>

                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][0].value}
                          onChangeText={(text) => updateCellState(1, 0, text)}
                          editable={!cellStates[1][0].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][1].value}
                          onChangeText={(text) => updateCellState(1, 1, text)}
                          editable={!cellStates[1][1].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][2].value}
                          onChangeText={(text) => updateCellState(1, 2, text)}
                          editable={!cellStates[1][2].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][3].value}
                          onChangeText={(text) => updateCellState(1, 3, text)}
                          editable={!cellStates[1][3].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][4].value}
                          onChangeText={(text) => updateCellState(1, 4, text)}
                          editable={!cellStates[1][4].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][5].value}
                          onChangeText={(text) => updateCellState(1, 5, text)}
                          editable={!cellStates[1][5].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][6].value}
                          onChangeText={(text) => updateCellState(1, 6, text)}
                          editable={!cellStates[1][6].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][7].value}
                          onChangeText={(text) => updateCellState(1, 7, text)}
                          editable={!cellStates[1][7].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][8].value}
                          onChangeText={(text) => updateCellState(1, 8, text)}
                          editable={!cellStates[1][8].locked}
                        />
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 150 }}></View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[1][9].value}
                          onChangeText={(text) => updateCellState(1, 9, text)}
                          editable={!cellStates[1][9].locked}
                        />
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 54 }}></View>
                      <View style={{ width: 16 }}>
                        <Text
                          style={{ fontSize: 20 }}
                          onPress={() => checkLetter(2)}>
                          3
                        </Text>
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[2][0].value}
                          onChangeText={(text) => updateCellState(2, 0, text)}
                          editable={!cellStates[2][0].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[2][1].value}
                          onChangeText={(text) => updateCellState(2, 1, text)}
                          editable={!cellStates[2][1].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[2][2].value}
                          onChangeText={(text) => updateCellState(2, 2, text)}
                          editable={!cellStates[2][2].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[2][3].value}
                          onChangeText={(text) => updateCellState(2, 3, text)}
                          editable={!cellStates[2][3].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[2][4].value}
                          onChangeText={(text) => updateCellState(2, 4, text)}
                          editable={!cellStates[2][4].locked}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={cellStates[2][5].value}
                          onChangeText={(text) => updateCellState(2, 5, text)}
                          editable={!cellStates[2][5].locked}
                        />
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 150 }}></View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 134 }}></View>
                      <View style={{ width: 16 }}>
                        <Text style={{ fontSize: 20 }}>4</Text>
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ width: 64 }}></View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 150 }}></View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                    </View>

                    <View style={{ flexDirection: 'row' }}>
                      <View style={{ width: 27 }}></View>
                      <View style={{ width: 16 }}>
                        <Text style={{ fontSize: 20 }}>5</Text>
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                      <View style={{ padding: 2, borderWidth: 1 }}>
                        <TextInput
                          placeholder={''}
                          size="20"
                          defaultValue={0}
                        />
                      </View>
                    </View>
                  </View>
                </View>
              </View>

              <ScrollView>
                <View style={{ height: 27 }}></View>
                <Heading
                  size="lg"
                  color="coolGray.800"
                  _dark={{ color: 'warmGray.50' }}
                  fontSize="30"
                  fontWeight="semibold">
                  Definitions
                </Heading>
                <Text>1. {definitions[0]}</Text>
                <Text>2. {definitions[1]}</Text>
                <Text>3. {definitions[2]}</Text>
                <Text>4. {definitions[2]}</Text>
                <Text>5. {definitions[2]}</Text>
              </ScrollView>
            </View>
          </VStack>
        </Box>
      </Center>
    </NativeBaseProvider>
  );
};

export default App;
