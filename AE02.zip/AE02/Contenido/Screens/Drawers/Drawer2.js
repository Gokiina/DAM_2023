//Cumple con todo lo solicitado
import { useState, useEffect, useMemo, useCallback } from 'react';
import { View, Text } from 'react-native';
import {
  Center,
  Box,
  Heading,
  VStack,
  NativeBaseProvider,
  Button,
} from 'native-base';

const Drawer2 = () => {
  const [definitions, setDefinitions] = useState([]);
  const [slicedWord, setSlicedWord] = useState([]);
  const [indicePalabra, setIndicePalabra] = useState(0);
  const [indiceDefinicion, setIndiceDefinicion] = useState(null);
  const [mensaje, setMensaje] = useState('');
  const [definicionCorrecta, setDefinicionCorrecta] = useState('');
  const words = useMemo(() => ['coding', 'mobile', 'phones'], []);

  useEffect(() => {
    const fetchData = async () => {
      await getDefinitions();
      setSlicedWord(words[indicePalabra]?.split('') || []);
    };

    fetchData();
  }, [getDefinitions, words, indicePalabra]);

  const comprobarRespuesta = () => {
    if (indiceDefinicion === null) {
      setMensaje('Por favor, selecciona una definición.');
      return;
    }

    const definicionSeleccionada = definitions[indiceDefinicion];

    if (definicionSeleccionada === definicionCorrecta) {
      setMensaje('Correcto');
      if (indicePalabra < words.length - 1) {
        setIndicePalabra(indicePalabra + 1);
        setIndiceDefinicion(null);
        setSlicedWord(words[indicePalabra + 1]?.split('') || []);
      } else {
        setMensaje('Juego terminado');
      }
    } else {
      setMensaje('Error. Intenta de nuevo.');
      setIndiceDefinicion(null);
    }
  };

  const handleGuessWord = async () => {
    await getDefinitions();
    setSlicedWord(words[0]?.split('') || []);
    setIndicePalabra(0);
    setIndiceDefinicion(null);
    setMensaje('');
  };

  const select = (index) => {
    setIndiceDefinicion(index);
    setMensaje('');
  };

  const getDefinitions = useCallback(async () => {
    let newDefinitions = [];
    for (let word of words) {
      try {
        const response = await fetch(
          `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`
        );
        const data = await response.json();
        const definition =
          data[0]?.meanings[0]?.definitions[0]?.definition ||
          'Definicion no encontrada';
        newDefinitions.push(definition);
      } catch (error) {
        console.error('Error ', error);
      }
    }
    setDefinitions(newDefinitions);
    setDefinicionCorrecta(newDefinitions[indicePalabra]);
  }, [words, indicePalabra]);

  return (
    <NativeBaseProvider>
      <Center w="80%">
        <Box safeArea p="2" w="90%" maxW="290" py="5">
          <Heading
            onPress={handleGuessWord}
            size="lg"
            color="coolGray.800"
            _dark={{ color: 'warmGray.50' }}
            fontSize="45"
            fontWeight="semibold">
            Guess word
          </Heading>

          <VStack space={2} mt="5">
            <View style={{ flexDirection: 'row' }}>
              {slicedWord.map((letter, index) => (
                <View style={{ padding: 2 }} key={index}>
                  <Text
                    style={{
                      width: 50,
                      color: 'white',
                      fontSize: 30,
                      backgroundColor: 'blue',
                      textAlign: 'center',
                      height: 55,
                    }}>
                    {letter}
                  </Text>
                </View>
              ))}
            </View>
          </VStack>

          {definitions.map((v, key) => (
            <VStack space={2} mt="2" key={key}>
              <View style={{ flexDirection: 'row' }}>
                <View style={{ padding: 2 }}>
                  <Button
                    size="55"
                    mt="-1"
                    colorScheme="yellow"
                    onPress={() => select(key)}
                    style={{ width: 320, height: 100 }}>
                    {v}
                  </Button>
                </View>
              </View>
            </VStack>
          ))}

          <VStack space={2} mt="2">
            <View style={{ flexDirection: 'row' }}>
              <View style={{ padding: 2 }}>
                <Button
                  size="55"
                  mt="-1"
                  colorScheme="green"
                  onPress={comprobarRespuesta}
                  isDisabled={indiceDefinicion === null}>
                  Check
                </Button>
                <Text
                  style={{
                    width: 350,
                    color: 'black',
                    fontSize: 20,
                    height: 55,
                  }}>
                  {mensaje}
                </Text>
              </View>
            </View>
          </VStack>
        </Box>
      </Center>
    </NativeBaseProvider>
  );
};

export default Drawer2;
