import { TouchableOpacity, Text, View, StyleSheet } from 'react-native';
import { useEffect, useState } from 'react';
import listening from '../files/listening.json';
import { Audio } from 'expo-av';

export default function Listening() {
  // VARIABLES
  const [nivel, setNivel] = useState(1);
  const palabrasLevelOne = listening[0].levelOne;
  const palabrasLevelTwo = listening[0].levelTwo;
  const [grupoPalabras, setGrupoPalabras] = useState([]); // valido para los dos niveles
  const [sound, setSound] = useState(null);
  const [palabraAdivinar, setPalabraAdivinar] = useState(null);
  const [fallos, setFallos] = useState(0);
  const [juegoTerminado, setJuegoTerminado] = useState(false);
  const [detenerIntercalacion, setDetenerIntercalacion] = useState(false);

  // USE EFFECT
  useEffect(() => {
      cargarPalabraAdivinar();
  }, [nivel]);

  useEffect(() => {
    if (palabraAdivinar) {
      getDatos();
    }
    const intervalId = setInterval(() => {
      intercalarPalabras();
    }, 100);
    setTimeout(() => {
      clearInterval(intervalId);
      setDetenerIntercalacion(true);
    }, 3000);
    return () => clearInterval(intervalId);
  }, [palabraAdivinar]);

  useEffect(() => {
      playLocalSound();
  }, [sound]);



  // FUNCIONES
  const cargarPalabraAdivinar = async () => {
    let grupo = [];
    let palabras = [];
    let size;

    if (nivel === 1) {
      palabras = palabrasLevelOne;
      size = 4;
    } else {
      palabras = palabrasLevelTwo;
      size = 9;
    }

    while (grupo.length < size) {
      let palabra = palabras[Math.floor(Math.random() * palabras.length)];
      if (!grupo.includes(palabra)) grupo.push(palabra);
    }

    setGrupoPalabras(grupo);
    setPalabraAdivinar(grupo[Math.floor(Math.random() * grupo.length)]);
    setDetenerIntercalacion(false);
  };

  const getDatos = async () => {
    try {
      const response = await fetch(
        `https://api.dictionaryapi.dev/api/v2/entries/en/${palabraAdivinar}`
      );
      if (response.ok) {
        const res = await response.json();
        if (res.length > 0) {
          const audio = res[0].phonetics[0].audio;
          setSound(audio);
          console.log('NIVEL: ' + nivel);
          console.log('Respuesta: ' + palabraAdivinar);
        } else {
          console.log('No se encontraron resultados');
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const intercalarPalabras = () => {
    if (!detenerIntercalacion) {
      let nuevoGrupoPalabras = Array.from(grupoPalabras);

      for (let i = nuevoGrupoPalabras.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [nuevoGrupoPalabras[i], nuevoGrupoPalabras[j]] = [
          nuevoGrupoPalabras[j],
          nuevoGrupoPalabras[i],
        ];
      }
      setGrupoPalabras(nuevoGrupoPalabras);
    }
  };

  const comprobacion = async (palabra) => {
    if (palabra == palabraAdivinar) {
      console.log('¡Palabra correcta!');
      if (nivel === 1) {
        alert('Pasando al segundo nivel...');
        setNivel(2);
      } else if (nivel === 2) {
        alert('¡Has ganado!');
        setJuegoTerminado(true);
      }
    } else {
      console.log(
        'Error ' +
          (fallos + 1) +
          ': La palabra seleccionada no corresponde con el audio. Inténtalo de nuevo.'
      );
      setFallos(fallos + 1);
      if (fallos >= 2) {
        alert('Has cometido más de dos fallos. Fin del juego.');
              setJuegoTerminado(true);
    } else {
      // Restablecer el nivel a 1 en caso de perder en el nivel 1
      setNivel(1);
      }
    }
  };

  const playLocalSound = async () => {
    const { sound: soundObject } = await Audio.Sound.createAsync({
      uri: sound,
    });
    await soundObject.playAsync();
    console.log('> Audio reproducido <');
  };

  const reiniciarJuego = () => {
    setFallos(0);
    setJuegoTerminado(false);
    setDetenerIntercalacion(false);
    setSound(null);
    cargarPalabraAdivinar(); 
  };
  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: 100,
      }}>
      {juegoTerminado ? (
        <TouchableOpacity onPress={reiniciarJuego} style={styles.botonAzul}>
          <Text style={{ color: 'white' }}>Try again</Text>
        </TouchableOpacity>
      ) : (
        <View style={{ padding: 2 }}>
          {Array(Math.sqrt(grupoPalabras.length))
            .fill()
            .map((_, i) => (
              <View key={i} style={{ flexDirection: 'row' }}>
                {grupoPalabras
                  .slice(
                    i * Math.sqrt(grupoPalabras.length),
                    (i + 1) * Math.sqrt(grupoPalabras.length)
                  )
                  .map((palabra, index) => (
                    <View key={index} style={{ padding: 2 }}>
                      <TouchableOpacity
                        onPress={() => comprobacion(palabra)}
                        style={styles.botonAzul}>
                        <Text style={{ color: 'white' }}>{palabra}</Text>
                      </TouchableOpacity>
                    </View>
                  ))}
              </View>
            ))}
        </View>
      )}
    </View>
  );
}

// ESTILOS
const styles = StyleSheet.create({
  botonAzul: {
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    textAlignVertical: 'center',
    width: 80,
    height: 80,
    backgroundColor: 'blue',
  },
});
