import {
  TouchableOpacity,
  Text,
  View,
  TextInput,
} from 'react-native';
import { useEffect, useState } from 'react';
import fillInTheGaps from '../files/fill_in_the_gaps.json';
import { Audio } from 'expo-av';

export default function FillInTheGaps() {
  // VARIABLES
  const [nivel, setNivel] = useState(1);
  const palabrasLevelOne = fillInTheGaps[0].levelOne;
  const palabrasLevelTwo = fillInTheGaps[0].levelTwo;
  const [sound, setSound] = useState(null);
  const [palabraAdivinar, setPalabraAdivinar] = useState(null);
  const [frase, setFrase] = useState(null);
  const [fallos, setFallos] = useState(0);
  const [juegoTerminado, setJuegoTerminado] = useState(false);
  const [textoIngresado, setTextoIngresado] = useState('');

  // USE EFFECT
  useEffect(() => {
    cargarPalabraAdivinar();
  }, [nivel]);

  useEffect(() => {
    if (palabraAdivinar) {
      getDatos();
    }
  }, [palabraAdivinar]);

  useEffect(() => {
    if (sound && !juegoTerminado) {
      playLocalSound();
      setSound(null);
    }
  }, [sound]);

  // FUNCIONES
  const cargarPalabraAdivinar = () => {
    let sentences;
    let palabras;

    if (nivel === 1) {
      sentences = palabrasLevelOne.sentences;
      palabras = palabrasLevelOne.adjectives;
    } else {
      sentences = palabrasLevelTwo.sentences;
      palabras = palabrasLevelTwo.adjectives;
    }

    const indiceAleatorio = Math.floor(Math.random() * sentences.length);
    const sentence = sentences[indiceAleatorio];
    const palabraSeleccionada = palabras[indiceAleatorio];

    setFrase(sentence);
    setPalabraAdivinar(palabraSeleccionada);
  };

  const getDatos = async () => {
    try {
      const response = await fetch(
        `https://api.dictionaryapi.dev/api/v2/entries/en/${palabraAdivinar}`
      );
      if (response.ok) {
        const res = await response.json();
        if (res.length > 0) {
          const audio = res[0].phonetics[0].audio;
          setSound(audio);
          console.log('NIVEL: ' + nivel);
          console.log('Respuesta: ' + palabraAdivinar);
        } else {
          console.log('No se encontraron resultados');
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const comprobacion = async (palabra) => {
    if (juegoTerminado) {
      console.log('El juego ha terminado. Reinícialo para jugar de nuevo.');
      return;
    }

    if (textoIngresado === palabraAdivinar) {
      console.log('¡Palabra correcta!');
      if (nivel === 1) {
        alert('Pasando al segundo nivel...');
        setTextoIngresado('');
        setNivel(2);
      } else if (nivel === 2) {
        alert('¡Has ganado!');
        setTextoIngresado('');
        setJuegoTerminado(true);
      }
    } else {
      console.log(
        'Error ' +
          (fallos + 1) +
          ': La palabra seleccionada no corresponde con el audio. Inténtalo de nuevo.'
      );
      setFallos(fallos + 1);
      if (fallos >= 2) {
        alert('Has cometido más de dos fallos. Fin del juego.');
        setTextoIngresado('');
        setJuegoTerminado(true);
      }
    }
  };

  const playLocalSound = async () => {
    const { sound: soundObject } = await Audio.Sound.createAsync({
      uri: sound,
    });
    await soundObject.playAsync();
    console.log('> Audio reproducido <');
  };

  const reiniciarJuego = () => {
    setNivel(1);
    setFallos(0);
    setJuegoTerminado(false);
    cargarPalabraAdivinar();
    setSound(null);
  };

  return (
    <View
      style={{
        justifyContent: 'row',
        alignSelf: 'center',
        marginVertical: 80,
      }}>
      {juegoTerminado ? (
        <TouchableOpacity
          onPress={reiniciarJuego}
          style={{
            color: 'white',
            borderRadius: 8,
            justifyContent: 'center',
            textAlignVertical: 'center',
            backgroundColor: 'black',
            height: 80,
          }}>
          <Text style={{ fontSize: 20, color: 'white'}}>Try again</Text>
        </TouchableOpacity>
      ) : (
        <View style={{ flexDirection: 'row' }}>
          <View style={{ padding: 2 }}>
            <Text style={{ fontSize: 20, color: 'black' }}>{frase}</Text>
          </View>
        </View>
      )}
      <TextInput
        style={{
          color: 'white',
          borderRadius: 8,
          justifyContent: 'center',
          alignItems: 'center',
          textAlignVertical: 'center',
          backgroundColor: 'black',
          height: 80,
        }}
        value={textoIngresado}
        onChangeText={(text) => setTextoIngresado(text.toLowerCase())}
      />
      <TouchableOpacity
        onPress={comprobacion}
        style={{
          borderRadius: 8,
          justifyContent: 'center',
          alignItems: 'center',
          textAlignVertical: 'center',
          backgroundColor: 'black',
          height: 80,
        }}>
        <Text style={{ fontSize: 20, color: 'white' }}>Check!</Text>
      </TouchableOpacity>
    </View>
  );
}
