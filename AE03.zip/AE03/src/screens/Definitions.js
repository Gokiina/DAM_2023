import {
  TouchableOpacity,
  Text,
  View,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { useEffect, useState } from 'react';
import definitions from '../files/definitions.json';
import { Audio } from 'expo-av';

export default function Definitions() {
  // VARIABLES
  const [nivel, setNivel] = useState(1);
  const palabrasLevelOne = definitions[0].levelOne;
  const palabrasLevelTwo = definitions[0].levelTwo;
  const [datos, setDatos] = useState('');
  const [palabrasDefDesordenadas, setPalabrasDefDesordenadas] = useState([]);
  const [sound, setSound] = useState(null);
  const [palabrasOrdenCorrecto, setPalabrasOrdenCorrecto] = useState([]);
  const [palabrasSeleccionadas, setPalabrasSeleccionadas] = useState([]);
  const [fallos, setFallos] = useState(0);
  const [juegoTerminado, setJuegoTerminado] = useState(false);
  const [palabraRandom, setPalabraRandom] = useState(null);
  const [audioReproducidoNivel, setAudioReproducidoNivel] = useState(false);

  // USE EFFECT
  useEffect(() => {
    if (palabraRandom && !audioReproducidoNivel) {
      getDatos();
    }
  }, [palabraRandom]);

  useEffect(() => {
    if (datos) separarDefinicion();
    setPalabrasOrdenCorrecto(datos.split(' '));
  }, [datos]);

  useEffect(() => {
    if (sound && !juegoTerminado) {
      playLocalSound();
      setAudioReproducidoNivel(true);
    }
  }, [sound]);

  useEffect(() => {
    if (!audioReproducidoNivel) {
      obtenerNuevaPalabra();
    }
  }, [nivel]);

  useEffect(() => {
    setNivel(1);
    setAudioReproducidoNivel(false);
  }, [juegoTerminado]);

  useEffect(() => {
    setPalabraRandom(
      palabrasLevelOne[Math.floor(Math.random() * palabrasLevelOne.length)]
    );
  }, []);

  // FUNCIONES
  const seleccionarPalabra = (palabra, index) => {
    var nuevasPalabrasSeleccionadas = [];
    for (var i = 0; i < palabrasSeleccionadas.length; i++) {
      nuevasPalabrasSeleccionadas[i] = palabrasSeleccionadas[i];
    }
    nuevasPalabrasSeleccionadas.push({ palabra, index });
    setPalabrasSeleccionadas(nuevasPalabrasSeleccionadas);

    if (nuevasPalabrasSeleccionadas.length === 2) {
      var newPalabrasDefDesordenadas = [];
      for (var i = 0; i < palabrasDefDesordenadas.length; i++) {
        newPalabrasDefDesordenadas[i] = palabrasDefDesordenadas[i];
      }
      var temp =
        newPalabrasDefDesordenadas[nuevasPalabrasSeleccionadas[0].index];
      newPalabrasDefDesordenadas[nuevasPalabrasSeleccionadas[0].index] =
        newPalabrasDefDesordenadas[index];
      newPalabrasDefDesordenadas[index] = temp;
      setPalabrasDefDesordenadas(newPalabrasDefDesordenadas);
      setPalabrasSeleccionadas([]);
    }
  };

  const obtenerNuevaPalabra = () => {
    let palabraSeleccionada;
    if (nivel == 1) {
      palabraSeleccionada =
        palabrasLevelOne[Math.floor(Math.random() * palabrasLevelOne.length)];
    } else {
      palabraSeleccionada =
        palabrasLevelTwo[Math.floor(Math.random() * palabrasLevelTwo.length)];
    }
    setPalabraRandom(palabraSeleccionada);
  };

  const getDatos = async () => {
    try {
      const response = await fetch(
        `https://api.dictionaryapi.dev/api/v2/entries/en/${palabraRandom}`
      );
      if (response.ok) {
        const res = await response.json();
        if (res.length > 0) {
          const definicion = res[0].meanings[0].definitions[0].definition;
          const audio = res[0].phonetics[0].audio;
          setSound(audio);
          console.log('NIVEL: ' + nivel);
          setDatos(definicion);
          console.log('palabra random: ' + palabraRandom);
          console.log('Respuesta: ' + definicion);
        } else {
          console.log('No se encontraron resultados');
          setDatos('');
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  const separarDefinicion = () => {
    const palabras = datos.split(' ');
    const palabrasDefDesordenadas = palabras.sort(() => Math.random() - 0.5);
    setPalabrasDefDesordenadas(palabrasDefDesordenadas);
  };

  const comprobarOrden = () => {
    var esCorrecto = true;
    for (var i = 0; i < palabrasDefDesordenadas.length; i++) {
      if (palabrasDefDesordenadas[i] !== palabrasOrdenCorrecto[i]) {
        esCorrecto = false;
        break;
      }
    }

    if (esCorrecto) {
      console.log('¡El orden de las palabras seleccionadas es correcto!');
      if (nivel === 1) {
        alert('Pasando al segundo nivel...');
        setAudioReproducidoNivel(false);
        setNivel(2);
      } else if (nivel === 2) {
        alert('¡Has ganado!');
        setJuegoTerminado(true);
      }
    } else {
      console.log(
        'Error ' +
          (fallos + 1) +
          ': El orden de las palabras seleccionadas es incorrecto. Inténtalo de nuevo.'
      );
      setFallos(fallos + 1);
      if (fallos >= 2) {
        alert('Has cometido más de dos fallos. Fin del juego.');
        setAudioReproducidoNivel(false);

        setJuegoTerminado(true);
      }
    }
  };

  const playLocalSound = async () => {
    const { sound: soundObject } = await Audio.Sound.createAsync({
      uri: sound,
    });
    await soundObject.playAsync();
  };

  const reiniciarJuego = () => {
    setNivel(1);
    setFallos(0);
    setJuegoTerminado(false);
    setPalabraRandom(
      palabrasLevelOne[Math.floor(Math.random() * palabrasLevelOne.length)]
    );
  };

  // PANTALLA
  return (
    <View
      style={{
        justifyContent: 'center',
        alignSelf: 'center',
        marginVertical: 80,
      }}>
      {juegoTerminado ? (
        <TouchableOpacity onPress={reiniciarJuego} style={styles.botonAzul}>
          <Text style={{ color: 'white' }}>Try again</Text>
        </TouchableOpacity>
      ) : (
        <View style={{ flexDirection: 'column' }}>
          <ScrollView vertical={true}>
            {palabrasDefDesordenadas.map((palabra, index) => (
              <View key={index} style={{ padding: 2 }}>
                <TouchableOpacity
                  onPress={() => seleccionarPalabra(palabra, index)}
                  style={styles.botonAzul}>
                  <Text style={{ color: 'white' }}>{palabra}</Text>
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>
          <TouchableOpacity onPress={comprobarOrden} style={styles.botonNegro}>
            <Text style={{ color: 'white' }}>Comprobar</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

// ESTILOS
const styles = StyleSheet.create({
  botonAzul: {
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    textAlignVertical: 'center',
    width: 80,
    height: 80,
    backgroundColor: 'blue',
  },
  botonNegro: {
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    textAlignVertical: 'center',
    width: 80,
    height: 80,
    backgroundColor: 'black',
  },
});
