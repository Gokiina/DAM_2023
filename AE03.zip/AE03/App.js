/* 
Tab: navegación de cuatro pantallas a las que se podrá acceder mediante cuatro pestañas ubicadas en el borde inferior de la pantalla (1 punto).
Nota: para ver con mayor detalle la navegación, se recomienda ver el video publicado en Florida Oberta.
A partir de los dos archivos proporcionados, Definitions.js, Listening.js, FillInTheGaps.js y Synonyms.js, se deberá implementar para cada una de las cuatro pantallas de la navegación Tab, las siguientes funcionalidades:
*/
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import Definitions from './src/screens/Definitions';
import Listening from './src/screens/Listening';
import FillInTheGaps from './src/screens/FillInTheGaps';

const Tab = createBottomTabNavigator();

const App = () => (
	<NavigationContainer>
		<Tab.Navigator>
			<Tab.Screen name="Definitions" component={Definitions}/>
			<Tab.Screen name="Listening" component={Listening}/>
      		<Tab.Screen name="FillInTheGaps" component={FillInTheGaps}/>
		</Tab.Navigator>
	</NavigationContainer>
);

export default App;
