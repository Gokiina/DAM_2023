import { useState } from 'react';
import { Text, View, TouchableOpacity } from 'react-native';

export default function App() {
  const [valorTecla, setValorTecla] = useState('');
  const [valorResultado, setValorResultado] = useState('');

  const [operando1, setOperando1] = useState('');
  const [operacion, setOperacion] = useState('');
  const [operacionEnCurso, setOperacionEnCurso] = useState('');
  const [displayResultado, setDisplayResultado] = useState('');

  const addDigito = (digito) => {
    const ultimoCaracterEsPunto = valorTecla.charAt(valorTecla.length - 1) === '.';

    if (digito === '=' && operando1 !== '' && operacion !== '' && valorTecla !== '') {
      calcularResultado();
      return;
    }

    if (esOperador(digito)) {
      if (esOperador(operacion)) {
        return;
      }
      setOperando1(valorTecla);
      setOperacion(digito);
      setValorTecla('');
      setOperacionEnCurso(valorTecla + ' ' + digito);
    } else if (digito === '1/x') {
      calcularInverso();
    } else if (digito === '!') {
      calcularFactorial();
    } else if (digito === '√') {
      calcularRaizCuadrada();
    } else if (digito === 'ln') {
      calcularLogaritmoNeperiano(valorTecla);
    } else if (digito === 'log') {
      calcularLogaritmoBase10();
    } else if (digito === 'rad') {
      calcularRadianes();
    } else if (digito === 'deg') {
      calcularGrados();
    } else if (digito === 'sen') {
      calcularSeno();
    } else if (digito === 'cos') {
      calcularCoseno();
    } else if (digito === 'tan') {
      calcularTangente();
    } else if (digito === '.') {
      if (ultimoCaracterEsPunto) {
        return;
      } else {
        setValorTecla(valorTecla + digito);
        setOperacionEnCurso(operacionEnCurso + digito);
      }
    } else {
      if (valorResultado) {
        setValorTecla(digito);
        setValorResultado('');
        setOperacionEnCurso(digito);
      } else {
        setValorTecla(valorTecla + digito);
        setOperacionEnCurso(operacionEnCurso + digito);
      }
    }
  }

  const esOperador = (char) => {
    return ['+', '-', '*', '/'].includes(char);
  }

  const limpiar = () => {
    setValorTecla('');
    setValorResultado('0');
    setOperando1('');
    setOperacion('');
    setOperacionEnCurso('');
    setDisplayResultado('');
  }

  const calcularInverso = () => {
    if (valorTecla !== '') {
      let resultadoTemporal = 1 / parseFloat(valorTecla);
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso('1 / ' + valorTecla + ' = ' + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularFactorial = () => {
    if (valorTecla !== '') {
      let resultadoTemporal = 1;
      for(let i = 2; i <= parseFloat(valorTecla); i++) {
        resultadoTemporal *= i;
      }
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso(valorTecla + '! = ' + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularRaizCuadrada = () => {
    if (valorTecla !== '') {
      let resultadoTemporal = Math.sqrt(parseFloat(valorTecla));
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso('√' + valorTecla + ' = ' + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularLogaritmoNeperiano = (numero) => {
    if (numero > 0) {
      let resultadoTemporal = Math.log(numero);
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso('ln(' + numero + ') = ' + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularLogaritmoBase10 = () => {
    if (valorTecla !== '') {
      let resultadoTemporal = Math.log10(parseFloat(valorTecla));
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso('log(' + valorTecla + ') = ' + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularRadianes = () => {
    if (valorTecla !== '') {
      let resultadoTemporal = parseFloat(valorTecla) * (Math.PI / 180);
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso(valorTecla + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularGrados = () => {
    if (valorTecla !== '') {
      let resultadoTemporal = parseFloat(valorTecla) * (180 / Math.PI);
      setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
      setOperacionEnCurso(valorTecla + ' grados = ' + resultadoTemporal);
      setValorTecla('');
    }
  }

  const calcularOperacionUnaria = (operacion) => {
    return () => {
      if (valorTecla !== '') {
        const valorNumerico = parseFloat(valorTecla);
        const resultadoTemporal = operacion(valorNumerico);
        setValorResultado(resultadoTemporal.toFixed(10).slice(0, 11));
        setOperacionEnCurso(`${valorTecla} ${operacion.name} = ${resultadoTemporal}`);
        setValorTecla('');
      }
    };
  };

  const calcularSeno = calcularOperacionUnaria(Math.sin);
  const calcularCoseno = calcularOperacionUnaria(Math.cos);
  const calcularTangente = calcularOperacionUnaria(Math.tan);

  const eliminarCerosInnecesarios = (numero) => {
    const resultadoFormateado = parseFloat(numero);
    return resultadoFormateado.toString();
  }

  const calcularResultado = () => {
    if (operando1 === '' || operacion === '' || valorTecla === '') {
      return;
    }

    let resultadoTemporal = parseFloat(operando1);
    let resultadoMostrar = '';

    switch (operacion) {
      case '+':
        resultadoTemporal = resultadoTemporal + parseFloat(valorTecla);
        resultadoMostrar = operando1 + ' + ' + valorTecla;
        break;
      case '-':
        resultadoTemporal = resultadoTemporal - parseFloat(valorTecla);
        resultadoMostrar = operando1 + ' - ' + valorTecla;
        break;
      case '/':
        resultadoTemporal = resultadoTemporal / parseFloat(valorTecla);
        resultadoMostrar = operando1 + ' / ' + valorTecla;
        break;
      case '*':
        resultadoTemporal = resultadoTemporal * parseFloat(valorTecla);
        resultadoMostrar = operando1 + ' * ' + valorTecla;
        break;
      default:
        break;
    }

    const resultadoFormateado = resultadoTemporal.toString().slice(0, 9);
    const resultadoFinal = eliminarCerosInnecesarios(resultadoFormateado);

    setOperando1(resultadoFinal);
    setValorResultado(resultadoFinal);
    setOperacionEnCurso(resultadoMostrar + ' = ' + resultadoFinal);
    setOperacion('');
    setValorTecla('');
    setDisplayResultado(resultadoFinal);
  }



return (
<View style={{ justifyContent: 'center', alignSelf: "center", marginVertical: 80 }}>

        <Text style={{ fontSize: 45, fontWeight: "bold"}}>Calculadora</Text>
        <View style={{ marginTop: 5}}>
          <View style={{ flexDirection: "row", marginBottom: 10, height: 70, width: 340, borderRadius: 4, borderWidth: 1 }}>
            <Text style={{ fontSize: 50, textAlign: "right", flex: 1 }}>{ displayResultado || valorResultado || operacionEnCurso || valorTecla }</Text>
          </View>
          <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('sen')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>sen</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('cos')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>cos</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('tan')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>tan</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('deg')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>deg</Text></TouchableOpacity>
            </View>
          </View>
            <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('ln')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>ln</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('log')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>log</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito(Math.PI.toFixed(10))} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>&Pi;</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('rad')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>rad</Text></TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('1/x')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>1/X</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('!')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>!</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('√')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>√</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('/')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>/</Text></TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('7')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>7</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('8')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>8</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('9')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>9</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('*')}style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>x</Text></TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('4')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>4</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('5')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>5</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('6')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>6</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('-')}style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>-</Text></TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('1')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>1</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('2')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>2</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('3')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>3</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('+')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>+</Text></TouchableOpacity>
            </View>
          </View>
          <View style={{ flexDirection: "row" }}>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => limpiar()} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>C</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('0')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'blue'}}><Text>0</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => addDigito('.')} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>,</Text></TouchableOpacity>
            </View>
            <View style={{ padding: 3 }}>
              <TouchableOpacity onPress={() => calcularResultado()} style={{borderRadius: 8, justifyContent: 'center', alignItems: 'center', textAlignVertical: 'center', width: 80, height: 80, backgroundColor: 'gray'}}><Text>=</Text></TouchableOpacity>
            </View>
          </View>
        </View>
  </View>
)
}

