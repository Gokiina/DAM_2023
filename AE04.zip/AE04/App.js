import Memory from './src/screens/Memory';

export default function App() {
  return <Memory/>;
}
