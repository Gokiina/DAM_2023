import { useEffect, useState } from 'react';
import { View, StyleSheet, Text, Image, TouchableOpacity, Button } from 'react-native';

export default function App() {
  const [imagenes, setImagenes] = useState([]);
  const [seleccion, setSeleccion] = useState([]);
  const [fallos, setFallos] = useState(0);
  const [aciertos, setAciertos] = useState(0);
  const [mostrarImagenes, setMostrarImagenes] = useState([]);
  const [juegoIniciado, setJuegoIniciado] = useState(false);
  const [nivel, setNivel] = useState(1);
  const [perdido, setPerdido] = useState(false);
  const [mostrarBoton, setMostrarBoton] = useState(false);

  useEffect(() => {
    obtenerImg(); // Cargar imágenes al cambiar el nivel
  }, [nivel]);

  useEffect(() => {
    if (juegoIniciado) {
      const timeout = setTimeout(() => {
        setMostrarImagenes([]); // Ocultar las imágenes después de 1 segundo
      }, 1000);
      return () => clearTimeout(timeout); // Limpiar timeout al desmontar
    }
  }, [juegoIniciado]);

  useEffect(() => {
    if (seleccion.length === 2 || (nivel === 3 && seleccion.length === 3)) {
      const [primera, segunda, tercera] = seleccion;

      // Verificación de selección para nivel 3 (tríos)
      const esNivelTres = nivel === 3;
      const coincidePar = imagenes[primera] === imagenes[segunda];
      const coincideTrio = tercera && imagenes[primera] === imagenes[tercera];

      if (
        primera !== segunda &&
        (!esNivelTres || (tercera && primera !== tercera && segunda !== tercera))
      ) {
        if ((esNivelTres && coincideTrio) || (!esNivelTres && coincidePar)) {
          // Si es nivel 3 y coinciden los tres, o si es otro nivel y coinciden dos
          setAciertos(aciertos + 1);
          setMostrarImagenes(prevMostrarImagenes => {
            let nuevasImagenes = [primera, segunda];
            if (tercera) nuevasImagenes.push(tercera);
            return [...prevMostrarImagenes, ...nuevasImagenes];
          });
        } else {
          // Si falla, ocultar las seleccionadas
          setFallos(fallos + 1);
          setTimeout(() => {
            setMostrarImagenes(
              mostrarImagenes.filter(
                (img) => img !== primera && img !== segunda && img !== tercera
              )
            );
          }, 1000); // Aumentado el tiempo a 1 segundo para que se vea bien el fallo
        }
        setSeleccion([]);
      }
    }

    if (fallos === 3) {
      alert('Has perdido el juego');
      setPerdido(true);
    }

    // Comprobar si se ha completado el nivel
    const totalAciertos = nivel === 1 ? 6 : nivel === 2 ? 8 : 4; // Nivel 3: tríos
    if (aciertos === totalAciertos) {
      if (nivel === 3) {
        // Mostrar mensaje de victoria al completar el nivel 3
        alert('¡GENIAL, HAS GANADO!');
      } else {
        // Mostrar el botón después de un pequeño retraso en otros niveles
        setTimeout(() => {
          setMostrarBoton(true);
        }, 1000); // 1 segundo de retraso para mostrar el botón
      }
    }
  }, [seleccion]);

  const obtenerImg = async () => {
    let strImag = [];
    let numeros = [];
    let numImagenes = nivel === 1 ? 6 : nivel === 2 ? 8 : 4;

    // Generar un conjunto de imágenes
    while (numeros.length < numImagenes) {
      let random = Math.floor(Math.random() * 20) + 1;
      if (!numeros.includes(random)) numeros.push(random);
    }

    // Obtener las imágenes de la API de Rick y Morty
    for (let j = 0; j < numeros.length; j++) {
      try {
        const response = await fetch(
          `https://rickandmortyapi.com/api/character/${numeros[j]}`
        );
        if (response.ok) {
          const res = await response.json();
          strImag.push(res.image);
          strImag.push(res.image); // Añadir la imagen dos veces para crear pares
          if (nivel === 3) strImag.push(res.image); // Añadir una tercera imagen si es nivel 3
        }
      } catch (error) {
        console.log(error);
      }
    }
    strImag.sort(() => Math.random() - 0.5); // Barajar las imágenes
    setImagenes(strImag);

    // Inicializar las imágenes visibles por un breve momento
    let numElementos = numImagenes * (nivel === 3 ? 3 : 2);
    let mostrarImagenesArray = Array.from({ length: numElementos }, (_, i) => i);
    setMostrarImagenes(mostrarImagenesArray); // Mostrar todas las imágenes brevemente

    // Ocultar las imágenes después de 1 segundo
    setTimeout(() => {
      setMostrarImagenes([]);
    }, 1000);

    setJuegoIniciado(true);
    setPerdido(false); // Reiniciar estado de perdido
    setMostrarBoton(false); // Reiniciar el botón de nivel
  };

  const crearTablero = () => {
    let filas = nivel === 2 ? 4 : 3;
    let columnas = 4;
    let tablero = [];
    for (let i = 0; i < filas; i++) {
      let fila = [];
      for (let j = 0; j < columnas; j++) {
        let key = i * columnas + j;
        fila[j] = (
          <TouchableOpacity key={key} onPress={() => seleccionarImagen(key)}>
            <View style={styles.botonAzul}>
              {mostrarImagenes.includes(key) && (
                <Image style={styles.imagen} source={{ uri: imagenes[key] }} />
              )}
            </View>
          </TouchableOpacity>
        );
      }
      tablero[i] = (
        <View key={i} style={{ flexDirection: 'row' }}>
          {fila}
        </View>
      );
    }
    return tablero;
  };

  const seleccionarImagen = (index) => {
    if (
      (nivel === 3 ? seleccion.length < 3 : seleccion.length < 2) &&
      !seleccion.includes(index)
    ) {
      setSeleccion([...seleccion, index]);
      setMostrarImagenes([...mostrarImagenes, index]);
    }
  };

  const reiniciarJuego = () => {
    setAciertos(0);
    setFallos(0);
    setMostrarImagenes([]);
    setSeleccion([]);
    setJuegoIniciado(false);
    obtenerImg(); // Volver a obtener imágenes para reiniciar
    setPerdido(false); // Reiniciar el estado de perdido
    setMostrarBoton(false); // Reiniciar el botón
  };

  const pasarDeNivel = () => {
    setAciertos(0);
    setFallos(0);
    setMostrarImagenes([]);
    setSeleccion([]);
    setNivel(nivel + 1);
    setMostrarBoton(false); // Ocultar el botón al pasar de nivel
  };

  return (
    <View>
      <Text style={styles.titulo}>Memory</Text>
      <View style={styles.tablero}>{crearTablero()}</View>
      {mostrarBoton && ( // Mostrar botón de pasar de nivel
        <View style={styles.botonReiniciar}>
          <Button title="Pasar de Nivel" onPress={pasarDeNivel} />
        </View>
      )}
      {perdido && ( // Mostrar botón si se ha perdido
        <View style={styles.botonReiniciar}>
          <Button title="Reiniciar Juego" onPress={reiniciarJuego} />
        </View>
      )}
    </View>
  );
} 


const styles = StyleSheet.create({
  tablero: {
    alignItems: 'center',
  },
  botonAzul: {
    width: 75,
    height: 75,
    margin: 5,
    backgroundColor: 'blue',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
  },
  titulo: {
    margin: 10,
    padding: 30,
    paddingTop:70,
    fontSize: 40,
    fontWeight: 'bold',
  },
  imagen: {
    width: 70,
    height: 70,
    borderRadius: 8,
  },
});

const styles = StyleSheet.create({
  tablero: {
    alignItems: 'center',
  },
  botonAzul: {
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    textAlignVertical: 'center',
    width: 70,
    height: 70,
    margin: 5,
    backgroundColor: 'blue',
  },
  titulo: {
    margin: 10,
    padding: 30,
    paddingTop:70,
    fontSize: 40,
    fontWeight: 'bold',
  },
  imagen: {
    width: 70,
    height: 70,
    borderRadius: 8,
  },
});
